package com.porfolio.Dai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaiApplication.class, args);
	}

}
